//
// Created by Nguyen Duc Dung on 2019-02-15.
//
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iomanip>
#include <string>
#include <fstream>
/// Prototype declaration
void Initialization();
void Finalization();

void LoadConfiguration();
void LoadMenu();
void DisplayMenu();
void ProcessUserChoice();

///--------------------------------------------------------------------

bool __coreInitialized = false;  /// an example of global variable
std::string  __userChoice;               /// a global variable to store user choice
bool __isExiting = false;        /// this variable should be turn on when the program exits
std::string menu1;
std::string menu2;
std::string menu3;
std::string menu4;
std::string menu5;
// TODO: add more global variables to complete tasks

///--------------------------------------------------------------------
/**
 * Function: Initialization
 * Purpose:  Initialize anything necessary in your program before starting
 * Input:    None
 * Output:   None
 */
void Initialization() {
	LoadConfiguration();
	LoadMenu();
	// TODO: write the code to initialize the program
	__coreInitialized = true;
}

/**
 * Function: Finalization
 * Purpose:  Clean up everything before the program exits
 * Input:    None
 * Output:   None
 */
void Finalization() {
	// TODO: write the code to clean up when the program exits
	__coreInitialized = false;
}

void LoadConfiguration() {
	// TODO: write code to load data from the configuration 

	std::string temp; //variable to save every line in file temporarily
	int countLine{ 0 };
	int countWelcome{ 0 };

	std::ifstream conf("conf.json");
	//Print WelcomeText will begin here
	//the code include the reading file and print 
	while (std::getline(conf, temp)) {
		countLine++;
		//Check the line begin welcome text
		if (temp.find("WelcomeText") != std::string::npos)
			countWelcome = countLine;
		//Start to print welcome text
		if (temp.find("line") != std::string::npos && countLine > countWelcome) {
			int countC{ 0 };
			int beginCharacter{ 0 };
			int endCharacter{ 0 };
			//Find the right thing to print
			for (int i = 0; i < temp.size(); i++) {
				if (temp[i] == '\"') {
					countC++;
					if (countC == 3) beginCharacter = i + 1;
					if (countC == 4) endCharacter = i - 1;
				}
			}
			// Print welcome text
			for (int i = beginCharacter; i <= endCharacter; i++)
				std::cout << temp[i];
			std::cout << '\n';

		}

	}
	std::cout << '\n';
	conf.close();
}

void LoadMenu() {
	// TODO: write code to load menu from the configuration file
	std::string temp; //variable to save each line in file temporarily
	int countLine{ 0 };
	int countMenu{ 0 };
	std::ifstream conf("conf.json");

	while (std::getline(conf, temp)) {
		countLine++;//Use to count the line of text
		if (temp.find("Menu") != std::string::npos)
			countMenu = countLine;

		if (temp.find("opt") != std::string::npos && countLine > countMenu) {
			int countC{ 0 };
			int beginCharacter{ 0 };
			int endCharacter{ 0 };
			//Find the right thing to print that is inside the third and forth "
			for (int i = 0; i < temp.size(); i++) {
				if (temp[i] == '\"') {
					countC++;
					if (countC == 3) beginCharacter = i + 1;
					if (countC == 4) endCharacter = i - 1;
				}
			}
			//Save every line in menu
			if (countLine - countMenu == 1) menu1.assign(temp, beginCharacter, endCharacter - beginCharacter + 1);
			if (countLine - countMenu == 2) menu2.assign(temp, beginCharacter, endCharacter - beginCharacter + 1);
			if (countLine - countMenu == 3) menu3.assign(temp, beginCharacter, endCharacter - beginCharacter + 1);
			if (countLine - countMenu == 4) menu4.assign(temp, beginCharacter, endCharacter - beginCharacter + 1);
			if (countLine - countMenu == 5) menu5.assign(temp, beginCharacter, endCharacter - beginCharacter + 1);
		}
	}
	conf.close();
}


void DisplayMenu() {
	// TODO: Display the menu loaded from configuration file
	std::cout << "1. " << menu1 << '\n';
	std::cout << "2. " << menu2 << '\n';
	std::cout << "3. " << menu3 << '\n';
	std::cout << "4. " << menu4 << '\n';
	std::cout << "5. " << menu5 << '\n';

}

void ProcessUserChoice() {
	// TODO: Read user input and process
	bool isInteger = true;//Check input is integer
	std::cout << "Please select: ";

	std::getline(std::cin, __userChoice);
	//consider integer value
	for (int i = 0; i < __userChoice.size(); i++) {
		if (((int)__userChoice[i] != 43) && ((int)__userChoice[i] != 45) && ((int)__userChoice[i] != 32) && (((int)__userChoice[i] > 57) || ((int)__userChoice[i] < 48)))
		{
			std::cout << "Invalid input , please input an interge number .\n"; isInteger = false; break;
		}
	}
	if (isInteger == true) {
		// delete 0 or ++ character in front of input value
		while (((int)__userChoice[0] == 32) || ((int)__userChoice[0] == 43) || ((int)__userChoice[0] == 48))
		{
			__userChoice.assign(__userChoice, 1, __userChoice.size());
		}


		if (__userChoice == "1" | __userChoice == "2" | __userChoice == "3" | __userChoice == "4") {
			std::cout << "You select menu item " << __userChoice << ". Processing... Done\n";
		}
		else if (__userChoice == "5") {
			std::cout << "Exiting...";
			__isExiting = true;
		}
		else std::cout << "Please select number from 1 to 5\n ";
	}
}